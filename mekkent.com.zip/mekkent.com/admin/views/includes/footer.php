    </main>
    
    <footer class="admin-footer">
        <p>&copy; <?php echo date('Y'); ?> Real Estate Admin Panel</p>
    </footer>
    
    <script src="<?php echo BASE_URL; ?>admin/views/js/dashboard/desktop.js"></script>
    <script src="<?php echo BASE_URL; ?>admin/views/js/dashboard/mobile.js"></script>
</body>
</html>