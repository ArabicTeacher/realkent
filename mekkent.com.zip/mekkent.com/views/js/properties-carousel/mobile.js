// Mobile carousel behavior - delegate to desktop initialization (idempotent)
document.addEventListener('DOMContentLoaded', function() {
    // No-op: desktop.js handles initialization for all carousels responsively.
});
